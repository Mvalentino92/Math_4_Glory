import java.io.File;
import java.util.Scanner;
public class NumberMind
{
	public static final int d = 16;
	public static final int g = 22;
	public static void main(String[] args) throws Exception
	{
		//Initialize guess matrix.
		Scanner input = new Scanner(new File("matrix.txt"));
		int[][] guesses = new int[g][d];
		int[] quotas = new int[g];
		for(int i = 0; i < guesses.length; i++) 
		{
			for(int j = 0; j < guesses[i].length; j++) guesses[i][j] = input.nextInt();
			quotas[i] = input.nextInt();
		}
		int[] solution = new int[d];
		for(int i = 0; i < d; i++) solution[i] = -1;

		//Call the backtracking algorithm, if it returns true, confirm if there's a solution
		//If any of the columns are not filled, if a single number has not been guessed for that column,
		//that is a valid digit for it. 
		boolean[] placed = new boolean[d];
		if(backtrack(guesses,placed,quotas,solution,0,0))
		{
			boolean verdict = true;
			for(int i = 0; i < d; i++)
			{
				if(solution[i] == -1)
				{
					int[] digits = new int[10];
					for(int j = 0; j < g; j++)
					{
						int digit = guesses[j][i];
						digits[digit] = 1;
					}
					int sum = 0;
					for(int j = 0; j < digits.length; j++) sum += digits[j];
					if(sum == 9) 
					{
						for(int j = 0; j < digits.length; j++)
						{
							if(digits[j] == 0) solution[i] = j;
						}
					}
					else
					{
						verdict = false;
						break;
					}
				}
			}
			if(verdict)
			{
				for(int i = 0; i < d; i++) System.out.print(solution[i]);
				System.out.println();
			}
			else System.out.println("No solution exists.");
		}
		else System.out.println("No solution exsits.");
	}

	//The backtracking algorithm
	public static boolean backtrack(int[][] guesses, boolean[] placed, int[] quotas,int[] solution,
			                int row, int col)
	{
		//Base case, if we made it through all the guesses, potential solution!
		if(row == guesses.length) return true;

		//Base case, if quotas is 0, move down
		if(quotas[row] == 0) return backtrack(guesses,placed,quotas,solution,row + 1,0);

		//Attempt to find an assumed correct digit
		for(int j = col; j < d; j++)
		{
			int digit = guesses[row][j];
			if(assumeCorrect(guesses,placed,quotas,digit,row,j))
			{
				//Update once assume correct
				placed[j] = true;
				solution[j] = digit;
				quotas[row]--;

				//If the quota for this row is up, change rows
				if(quotas[row] == 0)
				{
					if(backtrack(guesses,placed,quotas,solution,row+1,0)) return true;
				}
				//Otherwise, only push the column forward
				else
				{
					if(backtrack(guesses,placed,quotas,solution,row,j+1)) return true;
				}

				//Revert was found not correct in future.
				placed[j] = false;
				solution[j] = -1;
				quotas[row]++;
				revertState(guesses,quotas,digit,g-1,row,j);
			}
		}
		return false;
	}

	//Returns true and changed the state of the matrix below if possible to place here
	public static boolean assumeCorrect(int[][] guesses, boolean[] placed, int[] quotas,int digit, int row,int col)
	{
		//If already placed here, or this digit matches a digit above
		//that by default has been assumed to be incorrect, return false.
		if(placed[col] == true) return false;
		for(int i = row - 1; i > -1; i--)
		{
			if(guesses[i][col] == digit) return false;
		}

		//Attempt to substract from quotas in the the rows below if they match this digit
		//If any of the quotas go below 0, this is not a valid move.
		//Save the spot where we stopped, and go revert the changed quotas to their previous state
		boolean possible = true;
		int killed = -1;
		for(int i = row + 1; i < g; i++)
		{
			if(guesses[i][col] == digit)
			{
				if(quotas[i] - 1 < 0)
				{
					possible = false;
					killed = i - 1;
					break;
				}
				else quotas[i]--;
			}
		}

		if(possible) return true;
		else
		{	
			revertState(guesses,quotas,digit,killed,row,col);
			return false;
		}
	}

	//Reverts the quotas within the bounds to their previous state. (Adding 1, since changing is always subtracting 1)
	public static void revertState(int[][] guesses, int[] quotas,int digit, int start, int stop, int col)
	{
		for(int i = start; i > stop; i--)
		{
			if(guesses[i][col] == digit) quotas[i]++;
		}
	}
}



